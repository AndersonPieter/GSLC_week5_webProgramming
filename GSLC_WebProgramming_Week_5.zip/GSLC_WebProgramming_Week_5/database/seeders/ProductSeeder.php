<?php

namespace Database\Seeders;

use App\Models\Product;
use Illuminate\Database\Seeder;

class ProductSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Product::query()->insert(
            [
                [
                    "id" => 1,
                    "name" => "Krisbow 5 Inci Kipas Angin Jepit Portabel",
                    "type" => "Alat Elektronik",
                    "desc" => "Dimensi produk : 15 x 11 x 20 cm",
                    "price" => 50000,
                    "image_path" => "https://res.cloudinary.com/ruparupa-com/image/upload/w_360,h_360,f_auto,q_auto/f_auto,q_auto:eco/v1666108177/Products/10165044_1.jpg"
                ],
                [
                    "id" => 2,
                    "name" => "Krisbow Set 28 Pcs Perkakas Mekanik Dengan Kotak",
                    "type" => "Perkakas",
                    "desc" => "Terdiri 28 pcs perkakas mekanik",
                    "price" => 120000,
                    "image_path" => "https://res.cloudinary.com/ruparupa-com/image/upload/w_360,h_360,f_auto,q_auto/f_auto,q_auto:eco/v1658329558/Products/10035393_1.jpg"
                ],
                [
                    "id" => 3,
                    "name" => "Krisbow 120x45x180 Cm Rak Besi 5 Tingkat - Abu-abu",
                    "type" => "Rak",
                    "desc" => "Kapasitas beban maksimum : 250 kg / rak",
                    "price" => 480000,
                    "image_path" => "https://res.cloudinary.com/ruparupa-com/image/upload/w_360,h_360,f_auto,q_auto/f_auto,q_auto:eco/v1503124803/Products/208855_1.jpg"
                ],
                [
                    "id" => 4,
                    "name" => "Krischef 400 Ml Gelas Plastik",
                    "type" => "Peralatan Makan dan Minum",
                    "desc" => "Kapasitas : 400 ml",
                    "price" => "10000",
                    "image_path" => "https://res.cloudinary.com/ruparupa-com/image/upload/w_360,h_360,f_auto,q_auto/f_auto,q_auto:eco/v1538064679/Products/10181202_1.jpg"
                ],
                [
                    "id" => 5,
                    "name" => "Ataru 12 Ltr Tempat Sampah Dengan Kompartemen Marble - Putih",
                    "type" => "Peralatan Kebersihan",
                    "desc" => "Dimensi produk : 28.8 x 22.8 x 33.3 cm",
                    "price" => 70000,
                    "image_path" => "https://res.cloudinary.com/ruparupa-com/image/upload/w_360,h_360,f_auto,q_auto/f_auto,q_auto:eco/v1659590490/Products/10490035_1.jpg"
                ]
            ]
        );
    }
}
