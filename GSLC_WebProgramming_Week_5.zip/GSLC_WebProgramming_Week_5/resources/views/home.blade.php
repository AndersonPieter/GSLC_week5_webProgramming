@extends('template')

@section('title', 'Home')

@section('content')

    <div class="container-fluid">
        <div class="container d-flex">
            @foreach($data as $d)
            <div class="card" style="width: 18rem;">
                <img src={{$d->image_path}} class="card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-title">{{$d->name}}</h5>
                    <p class="card-text">{{$d->desc}}</p>
                    <p class="card-text">{{$d->price}}</p>

                    @if($d->type === "Perkakas")
                        <span class="badge text-danger">{{$d->type}}</span>
                    @else
                        <span class="badge text-primary">{{$d->type}}</span>
                    @endif

                </div>
            </div>
            @endforeach
        </div>
    </div>


@endsection